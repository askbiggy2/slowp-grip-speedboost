Slowp grip boost — CLOUD BUILD PACKAGE

This is an attempt to build the source prototype in GitHub's cloud, so you do not need Android Studio on your PC.
It is NOT a finished mod until the workflow succeeds. Even if it builds, it is not tested in-game and could fail or crash because the game hook ABI and loader integration have not been verified.

WHAT YOU DO
1. Sign in to GitHub (create a free account if needed): https://github.com
2. Create a NEW repository. Name it slowp-grip-boost. Set it to Private if you prefer. Do not add a README or license.
3. Unzip this package on your PC.
4. On the new GitHub repository page, choose Add file > Upload files. Upload all the files AND folders from inside this unzipped folder, including the hidden .github folder. If Windows hides .github, enable View > Show > Hidden items, or create the workflow file via GitHub's web editor at .github/workflows/build-qmod.yml.
5. Commit the uploaded files.
6. Open the repository's Actions tab. Select “Build Slowp QuestPatcher mod” on the left, click “Run workflow,” then the green Run workflow button.
7. Wait for the run to finish. If it succeeds, open the completed run and download the artifact named “SlowpGripSpeedBoost-qmod”. Inside is SlowpGripSpeedBoost.qmod.
8. Transfer that .qmod to your PC and install it with QuestPatcher only if the build succeeded. Keep a backup of the game. If the game crashes, remove the mod in QuestPatcher.

IMPORTANT
- This workflow builds a prototype, not a guaranteed working mod. It uses the open-source Dobby hook library and the existing unverified C++ hooks.
- Do not upload your original 281 MB APK; the workflow does not need it.
- The mod is designed for Slowp 0.99.144 / package com.CruelByte.Slowp.
- The build can fail if upstream Dobby's build options or Android NDK compatibility have changed. A successful compile does not prove the hooks work in-game.
